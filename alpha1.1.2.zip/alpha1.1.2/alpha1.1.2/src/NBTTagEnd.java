// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.io.*;

public class NBTTagEnd extends NBTBase
{

    public NBTTagEnd()
    {
    }

    void func_736_a(DataInput datainput)
    {
    }

    void func_735_a(DataOutput dataoutput)
    {
    }

    public byte func_733_a()
    {
        return 0;
    }

    public String toString()
    {
        return "END";
    }
}
