// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.io.*;

public class Packet0KeepAlive extends Packet
{

    public Packet0KeepAlive()
    {
    }

    public void func_323_a(NetHandler nethandler)
    {
    }

    public void func_327_a(DataInputStream datainputstream)
    {
    }

    public void func_322_a(DataOutputStream dataoutputstream)
    {
    }

    public int func_329_a()
    {
        return 0;
    }
}
