// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.util.Random;

public class BlockObsidian extends BlockStone
{

    public BlockObsidian(int i, int j)
    {
        super(i, j);
    }

    public int func_229_a(Random random)
    {
        return 1;
    }

    public int func_240_a(int i, Random random)
    {
        return Block.obsidian.blockID;
    }
}
