// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 


public class NetHandler
{

    public NetHandler()
    {
    }

    public void func_833_a(Packet51MapChunk packet51mapchunk)
    {
    }

    public void func_836_b(Packet packet)
    {
    }

    public void func_823_a(String s)
    {
    }

    public void func_844_a(Packet255KickDisconnect packet255kickdisconnect)
    {
        func_836_b(packet255kickdisconnect);
    }

    public void func_840_a(Packet1Login packet1login)
    {
        func_836_b(packet1login);
    }

    public void func_837_a(Packet10Flying packet10flying)
    {
        func_836_b(packet10flying);
    }

    public void func_824_a(Packet52MultiBlockChange packet52multiblockchange)
    {
        func_836_b(packet52multiblockchange);
    }

    public void func_821_a(Packet14BlockDig packet14blockdig)
    {
        func_836_b(packet14blockdig);
    }

    public void func_822_a(Packet53BlockChange packet53blockchange)
    {
        func_836_b(packet53blockchange);
    }

    public void func_826_a(Packet50PreChunk packet50prechunk)
    {
        func_836_b(packet50prechunk);
    }

    public void func_820_a(Packet20NamedEntitySpawn packet20namedentityspawn)
    {
        func_836_b(packet20namedentityspawn);
    }

    public void func_827_a(Packet30Entity packet30entity)
    {
        func_836_b(packet30entity);
    }

    public void func_829_a(Packet34EntityTeleport packet34entityteleport)
    {
        func_836_b(packet34entityteleport);
    }

    public void func_819_a(Packet15Place packet15place)
    {
        func_836_b(packet15place);
    }

    public void func_841_a(Packet16BlockItemSwitch packet16blockitemswitch)
    {
        func_836_b(packet16blockitemswitch);
    }

    public void func_839_a(Packet29DestroyEntity packet29destroyentity)
    {
        func_836_b(packet29destroyentity);
    }

    public void func_832_a(Packet21PickupSpawn packet21pickupspawn)
    {
        func_836_b(packet21pickupspawn);
    }

    public void func_834_a(Packet22Collect packet22collect)
    {
        func_836_b(packet22collect);
    }

    public void func_831_a(Packet3Chat packet3chat)
    {
        func_836_b(packet3chat);
    }

    public void func_830_a(Packet17AddToInventory packet17addtoinventory)
    {
        func_836_b(packet17addtoinventory);
    }

    public void func_835_a(Packet23VehicleSpawn packet23vehiclespawn)
    {
        func_836_b(packet23vehiclespawn);
    }

    public void func_825_a(Packet18ArmAnimation packet18armanimation)
    {
        func_836_b(packet18armanimation);
    }

    public void func_838_a(Packet2Handshake packet2handshake)
    {
        func_836_b(packet2handshake);
    }

    public void func_828_a(Packet24MobSpawn packet24mobspawn)
    {
        func_836_b(packet24mobspawn);
    }

    public void func_846_a(Packet4UpdateTime packet4updatetime)
    {
        func_836_b(packet4updatetime);
    }

    public void func_843_a(Packet5PlayerInventory packet5playerinventory)
    {
        func_836_b(packet5playerinventory);
    }

    public void func_842_a(Packet59ComplexEntity packet59complexentity)
    {
        func_836_b(packet59complexentity);
    }

    public void func_845_a(Packet6SpawnPosition packet6spawnposition)
    {
        func_836_b(packet6spawnposition);
    }
}
