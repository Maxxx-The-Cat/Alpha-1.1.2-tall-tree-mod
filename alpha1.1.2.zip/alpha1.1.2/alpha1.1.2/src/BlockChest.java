// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.util.Random;

public class BlockChest extends BlockContainer
{

    protected BlockChest(int i)
    {
        super(i, Material.wood);
        field_457_a = new Random();
        field_378_bb = 26;
    }

    public int func_211_a(IBlockAccess iblockaccess, int i, int j, int k, int l)
    {
        if(l == 1)
        {
            return field_378_bb - 1;
        }
        if(l == 0)
        {
            return field_378_bb - 1;
        }
        int i1 = iblockaccess.func_600_a(i, j, k - 1);
        int j1 = iblockaccess.func_600_a(i, j, k + 1);
        int k1 = iblockaccess.func_600_a(i - 1, j, k);
        int l1 = iblockaccess.func_600_a(i + 1, j, k);
        if(i1 == blockID || j1 == blockID)
        {
            if(l == 2 || l == 3)
            {
                return field_378_bb;
            }
            int i2 = 0;
            if(i1 == blockID)
            {
                i2 = -1;
            }
            int k2 = iblockaccess.func_600_a(i - 1, j, i1 != blockID ? k + 1 : k - 1);
            int i3 = iblockaccess.func_600_a(i + 1, j, i1 != blockID ? k + 1 : k - 1);
            if(l == 4)
            {
                i2 = -1 - i2;
            }
            byte byte1 = 5;
            if((Block.field_343_p[k1] || Block.field_343_p[k2]) && !Block.field_343_p[l1] && !Block.field_343_p[i3])
            {
                byte1 = 5;
            }
            if((Block.field_343_p[l1] || Block.field_343_p[i3]) && !Block.field_343_p[k1] && !Block.field_343_p[k2])
            {
                byte1 = 4;
            }
            return (l != byte1 ? field_378_bb + 32 : field_378_bb + 16) + i2;
        }
        if(k1 == blockID || l1 == blockID)
        {
            if(l == 4 || l == 5)
            {
                return field_378_bb;
            }
            int j2 = 0;
            if(k1 == blockID)
            {
                j2 = -1;
            }
            int l2 = iblockaccess.func_600_a(k1 != blockID ? i + 1 : i - 1, j, k - 1);
            int j3 = iblockaccess.func_600_a(k1 != blockID ? i + 1 : i - 1, j, k + 1);
            if(l == 3)
            {
                j2 = -1 - j2;
            }
            byte byte2 = 3;
            if((Block.field_343_p[i1] || Block.field_343_p[l2]) && !Block.field_343_p[j1] && !Block.field_343_p[j3])
            {
                byte2 = 3;
            }
            if((Block.field_343_p[j1] || Block.field_343_p[j3]) && !Block.field_343_p[i1] && !Block.field_343_p[l2])
            {
                byte2 = 2;
            }
            return (l != byte2 ? field_378_bb + 32 : field_378_bb + 16) + j2;
        }
        byte byte0 = 3;
        if(Block.field_343_p[i1] && !Block.field_343_p[j1])
        {
            byte0 = 3;
        }
        if(Block.field_343_p[j1] && !Block.field_343_p[i1])
        {
            byte0 = 2;
        }
        if(Block.field_343_p[k1] && !Block.field_343_p[l1])
        {
            byte0 = 5;
        }
        if(Block.field_343_p[l1] && !Block.field_343_p[k1])
        {
            byte0 = 4;
        }
        return l != byte0 ? field_378_bb : field_378_bb + 1;
    }

    public int func_218_a(int i)
    {
        if(i == 1)
        {
            return field_378_bb - 1;
        }
        if(i == 0)
        {
            return field_378_bb - 1;
        }
        if(i == 3)
        {
            return field_378_bb + 1;
        } else
        {
            return field_378_bb;
        }
    }

    public boolean func_243_a(World world, int i, int j, int k)
    {
        int l = 0;
        if(world.func_600_a(i - 1, j, k) == blockID)
        {
            l++;
        }
        if(world.func_600_a(i + 1, j, k) == blockID)
        {
            l++;
        }
        if(world.func_600_a(i, j, k - 1) == blockID)
        {
            l++;
        }
        if(world.func_600_a(i, j, k + 1) == blockID)
        {
            l++;
        }
        if(l > 1)
        {
            return false;
        }
        if(func_286_h(world, i - 1, j, k))
        {
            return false;
        }
        if(func_286_h(world, i + 1, j, k))
        {
            return false;
        }
        if(func_286_h(world, i, j, k - 1))
        {
            return false;
        }
        return !func_286_h(world, i, j, k + 1);
    }

    private boolean func_286_h(World world, int i, int j, int k)
    {
        if(world.func_600_a(i, j, k) != blockID)
        {
            return false;
        }
        if(world.func_600_a(i - 1, j, k) == blockID)
        {
            return true;
        }
        if(world.func_600_a(i + 1, j, k) == blockID)
        {
            return true;
        }
        if(world.func_600_a(i, j, k - 1) == blockID)
        {
            return true;
        }
        return world.func_600_a(i, j, k + 1) == blockID;
    }

    public void func_214_b(World world, int i, int j, int k)
    {
        TileEntityChest tileentitychest = (TileEntityChest)world.func_603_b(i, j, k);
label0:
        for(int l = 0; l < tileentitychest.func_469_c(); l++)
        {
            ItemStack itemstack = tileentitychest.func_468_c(l);
            if(itemstack == null)
            {
                continue;
            }
            float f = field_457_a.nextFloat() * 0.8F + 0.1F;
            float f1 = field_457_a.nextFloat() * 0.8F + 0.1F;
            float f2 = field_457_a.nextFloat() * 0.8F + 0.1F;
            do
            {
                if(itemstack.stackSize <= 0)
                {
                    continue label0;
                }
                int i1 = field_457_a.nextInt(21) + 10;
                if(i1 > itemstack.stackSize)
                {
                    i1 = itemstack.stackSize;
                }
                itemstack.stackSize -= i1;
                EntityItem entityitem = new EntityItem(world, (float)i + f, (float)j + f1, (float)k + f2, new ItemStack(itemstack.itemID, i1, itemstack.itemDmg));
                float f3 = 0.05F;
                entityitem.motionX = (float)field_457_a.nextGaussian() * f3;
                entityitem.motionY = (float)field_457_a.nextGaussian() * f3 + 0.2F;
                entityitem.motionZ = (float)field_457_a.nextGaussian() * f3;
                world.func_674_a(entityitem);
            } while(true);
        }

        super.func_214_b(world, i, j, k);
    }

    public boolean func_250_a(World world, int i, int j, int k, EntityPlayer entityplayer)
    {
        Object obj = (TileEntityChest)world.func_603_b(i, j, k);
        if(world.func_601_g(i, j + 1, k))
        {
            return true;
        }
        if(world.func_600_a(i - 1, j, k) == blockID && world.func_601_g(i - 1, j + 1, k))
        {
            return true;
        }
        if(world.func_600_a(i + 1, j, k) == blockID && world.func_601_g(i + 1, j + 1, k))
        {
            return true;
        }
        if(world.func_600_a(i, j, k - 1) == blockID && world.func_601_g(i, j + 1, k - 1))
        {
            return true;
        }
        if(world.func_600_a(i, j, k + 1) == blockID && world.func_601_g(i, j + 1, k + 1))
        {
            return true;
        }
        if(world.func_600_a(i - 1, j, k) == blockID)
        {
            obj = new InventoryLargeChest("Large chest", (TileEntityChest)world.func_603_b(i - 1, j, k), ((IInventory) (obj)));
        }
        if(world.func_600_a(i + 1, j, k) == blockID)
        {
            obj = new InventoryLargeChest("Large chest", ((IInventory) (obj)), (TileEntityChest)world.func_603_b(i + 1, j, k));
        }
        if(world.func_600_a(i, j, k - 1) == blockID)
        {
            obj = new InventoryLargeChest("Large chest", (TileEntityChest)world.func_603_b(i, j, k - 1), ((IInventory) (obj)));
        }
        if(world.func_600_a(i, j, k + 1) == blockID)
        {
            obj = new InventoryLargeChest("Large chest", ((IInventory) (obj)), (TileEntityChest)world.func_603_b(i, j, k + 1));
        }
        entityplayer.func_452_a(((IInventory) (obj)));
        return true;
    }

    protected TileEntity func_283_a_()
    {
        return new TileEntityChest();
    }

    private Random field_457_a;
}
