// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 


public class GuiUnused extends GuiScreen
{

    public void func_575_a()
    {
    }

    public void func_571_a(int i, int j, float f)
    {
        func_549_a(0, 0, width, height, 0xff402020, 0xff501010);
        func_548_a(field_947_g, field_997_a, width / 2, 90, 0xffffff);
        func_548_a(field_947_g, field_998_h, width / 2, 110, 0xffffff);
        super.func_571_a(i, j, f);
    }

    protected void func_580_a(char c, int i)
    {
    }

    private String field_997_a;
    private String field_998_h;
}
