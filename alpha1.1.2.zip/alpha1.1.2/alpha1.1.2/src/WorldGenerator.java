// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.util.Random;

public abstract class WorldGenerator
{

    public WorldGenerator()
    {
    }

    public abstract boolean func_516_a(World world, Random random, int i, int j, int k);

    public void func_517_a(double d, double d1, double d2)
    {
    }
}
