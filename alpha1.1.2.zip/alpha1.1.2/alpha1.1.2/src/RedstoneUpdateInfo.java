// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 


class RedstoneUpdateInfo
{

    public RedstoneUpdateInfo(int i, int j, int k, long l)
    {
        field_1009_a = i;
        field_1008_b = j;
        field_1011_c = k;
        field_1010_d = l;
    }

    int field_1009_a;
    int field_1008_b;
    int field_1011_c;
    long field_1010_d;
}
