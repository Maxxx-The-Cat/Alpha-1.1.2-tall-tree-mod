// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 


public class ModelSheep1 extends ModelQuadraped
{

    public ModelSheep1()
    {
        super(12, 0.0F);
        field_1266_d = new ModelRenderer(0, 0);
        field_1266_d.func_923_a(-3F, -4F, -4F, 6, 6, 6, 0.6F);
        field_1266_d.func_925_a(0.0F, 6F, -8F);
        field_1265_e = new ModelRenderer(28, 8);
        field_1265_e.func_923_a(-4F, -10F, -7F, 8, 16, 6, 1.75F);
        field_1265_e.func_925_a(0.0F, 5F, 2.0F);
        float f = 0.5F;
        field_1264_f = new ModelRenderer(0, 16);
        field_1264_f.func_923_a(-2F, 0.0F, -2F, 4, 6, 4, f);
        field_1264_f.func_925_a(-3F, 12F, 7F);
        field_1263_g = new ModelRenderer(0, 16);
        field_1263_g.func_923_a(-2F, 0.0F, -2F, 4, 6, 4, f);
        field_1263_g.func_925_a(3F, 12F, 7F);
        field_1262_h = new ModelRenderer(0, 16);
        field_1262_h.func_923_a(-2F, 0.0F, -2F, 4, 6, 4, f);
        field_1262_h.func_925_a(-3F, 12F, -5F);
        field_1261_i = new ModelRenderer(0, 16);
        field_1261_i.func_923_a(-2F, 0.0F, -2F, 4, 6, 4, f);
        field_1261_i.func_925_a(3F, 12F, -5F);
    }
}
