// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 


public class MovementInput
{

    public MovementInput()
    {
        field_1174_a = 0.0F;
        field_1173_b = 0.0F;
        field_1177_c = false;
        field_1176_d = false;
        field_1175_e = false;
    }

    public void func_797_a(EntityPlayer entityplayer)
    {
    }

    public void func_798_a()
    {
    }

    public void func_796_a(int i, boolean flag)
    {
    }

    public float field_1174_a;
    public float field_1173_b;
    public boolean field_1177_c;
    public boolean field_1176_d;
    public boolean field_1175_e;
}
