// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 


public class ChatLine
{

    public ChatLine(String s)
    {
        field_1297_a = s;
        field_1296_b = 0;
    }

    public String field_1297_a;
    public int field_1296_b;
}
