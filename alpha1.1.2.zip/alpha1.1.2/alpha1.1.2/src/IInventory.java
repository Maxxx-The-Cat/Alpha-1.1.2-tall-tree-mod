// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 


public interface IInventory
{

    public abstract int func_469_c();

    public abstract ItemStack func_468_c(int i);

    public abstract ItemStack func_473_a(int i, int j);

    public abstract void func_472_a(int i, ItemStack itemstack);

    public abstract String func_471_d();

    public abstract int func_470_e();

    public abstract void func_474_j_();
}
