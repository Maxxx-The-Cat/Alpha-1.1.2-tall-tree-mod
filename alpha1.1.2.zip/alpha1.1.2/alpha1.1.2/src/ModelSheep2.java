// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 


public class ModelSheep2 extends ModelQuadraped
{

    public ModelSheep2()
    {
        super(12, 0.0F);
        field_1266_d = new ModelRenderer(0, 0);
        field_1266_d.func_923_a(-3F, -4F, -6F, 6, 6, 8, 0.0F);
        field_1266_d.func_925_a(0.0F, 6F, -8F);
        field_1265_e = new ModelRenderer(28, 8);
        field_1265_e.func_923_a(-4F, -10F, -7F, 8, 16, 6, 0.0F);
        field_1265_e.func_925_a(0.0F, 5F, 2.0F);
    }
}
