// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 


public class GuiSmallButton extends GuiButton
{

    public GuiSmallButton(int i, int j, int k, String s)
    {
        super(i, j, k, 150, 20, s);
    }
}
