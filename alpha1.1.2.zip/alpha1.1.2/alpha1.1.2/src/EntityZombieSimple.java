// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 


public class EntityZombieSimple extends EntityMobs
{

    public EntityZombieSimple(World world)
    {
        super(world);
        field_728_u = "/mob/zombie.png";
        field_722_aa = 0.5F;
        field_762_e = 50;
        health *= 10;
        field_645_aB *= 6F;
        func_371_a(field_644_aC * 6F, field_643_aD * 6F);
    }

    protected float func_439_a(int i, int j, int k)
    {
        return field_615_ag.func_598_c(i, j, k) - 0.5F;
    }
}
