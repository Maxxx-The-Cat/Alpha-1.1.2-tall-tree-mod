// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import paulscode.sound.codecs.CodecJOrbis;

public class CodecMus extends CodecJOrbis
{

    public CodecMus()
    {
    }

    protected InputStream openInputStream()
    {
        try {
			URL url = null;
			URLConnection urlConnection = null;
			return new MusInputStream(this, url, urlConnection.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
    }
}
