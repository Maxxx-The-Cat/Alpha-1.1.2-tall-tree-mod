// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.net.URL;

public class SoundPoolEntry
{

    public SoundPoolEntry(String s, URL url)
    {
        field_1781_a = s;
        field_1780_b = url;
    }

    public String field_1781_a;
    public URL field_1780_b;
}
